Certbot logs copied
